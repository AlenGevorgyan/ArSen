from datetime import datetime
import json


class Plant:
    """Class representing a single plant."""
    def __init__(self, name, ptype, size):
        self.name = name
        self.ptype = ptype
        self.size = size
        self.last_watered = None
        self.ai_status = 'Unknown'


    def water(self):
        """marks the plant as watered and updates last_watered"""
        self.last_watered = datetime.now()
        print(f"{self.name} has watered in {self.last_watered.strftime('%Y-%m-%d %H:%M')}")


    def analyze(self, status):
        """updates the plant's ai_status"""
        self.ai_status = status
        print(f"{self.name}: status tas updated to {self.ai_status}")

    def to_dict(self):
        """returns a dictionary of the plant's fields for JSON/frontend"""
        return {
            "name": self.name,
            "type": self.ptype,
            "size": self.size,
            "last_watered": self.last_watered.strftime("%Y-%m-%d %H:%M") if self.last_watered else None,
            "ai_status": self.ai_status
        }


class Garden:
    """Class representing a garden containing plants."""
    def __init__(self, name):
        self.name = name
        self.plants: list[Plant] = []
        self.notifications = {"watering": True}

    def add_plant(self, plant: Plant):
        """adds a Plant object to the garden"""
        self.plants.append(plant)
        print(f'Has appended plant {plant.name} to garden {self.name}')

    def toggle_notifications(self, state: bool):
        """enables or disables watering notifications"""
        self.notifications["watering"] = state

    def list_plants(self):
        """returns a list of all plants with their ai_status"""
        for plant in self.plants:
            print(f"— {plant.name} | Status: {plant.ai_status}")

    def to_dict(self):
        """returns a dictionary of the garden and all its plants for JSON/frontend"""
        return {
            'name': self.name,
            'plants': [p.to_dict() for p in self.plants],
            'notifications': self.notifications
        }


def gardens_to_dict(gardens: list[Garden]):
    """
    Converts a list of Garden objects into a dictionary suitable for JSON/frontend.

    Arguments:
    - gardens: list of Garden objects

    Returns:
    - a dictionary in the format {"gardens": [...]}
    """
    return {
        'gardens' : [g.to_dict() for g in gardens]
    }


def plant_from_json(data):
    """
    Creates a Plant object from a dictionary containing name, type, and size.

    Arguments:
    - data: dictionary with keys "name", "type", "size"

    Returns:
    - a Plant object
    """
    return Plant(data["name"], data["type"], data["size"])


def save_gardens_to_file(gardens: list, filename="gardens.json"):
    """
    Saves a list of gardens to a JSON file.

    Arguments:
    - gardens: list of Garden objects
    - filename: file name for saving (default "gardens.json")
    """
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(gardens_to_dict(gardens), f, ensure_ascii=False, indent=2)
    print(f"Gardens has saved to {filename}")


def load_gardens_from_file(filename="gardens.json"):
    """
    Loads a list of gardens from a JSON file and restores Garden and Plant objects.

    Arguments:
    - filename: file name for loading (default "gardens.json")

    Returns:
    - list of Garden objects
    """
    with open(filename, "r", encoding="utf-8") as f:
        data = json.load(f)
    gardens = []
    for g in data["gardens"]:
        garden = Garden(g["name"])
        for p in g["plants"]:
            plant = Plant(p["name"], p["type"], p["size"])
            plant.ai_status = p["ai_status"]
            if p["last_watered"]:
                from datetime import datetime
                plant.last_watered = datetime.strptime(p["last_watered"], "%Y-%m-%d %H:%M")
            garden.add_plant(plant)
        gardens.append(garden)
    return gardens

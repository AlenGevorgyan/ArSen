from flask import Flask, jsonify, request, send_from_directory
import os
import json

from Main import Garden, Plant, load_gardens_from_file, save_gardens_to_file, gardens_to_dict


APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(APP_DIR, 'static')
DATA_FILE = os.path.join(APP_DIR, 'gardens.json')

app = Flask(__name__, static_folder=STATIC_DIR)


def ensure_data_file():
    if not os.path.exists(DATA_FILE):
        # create an empty gardens structure
        save_gardens_to_file([], DATA_FILE)


@app.route('/')
def index():
    return send_from_directory(APP_DIR, 'index.html')


@app.route('/static/<path:filename>')
def static_files(filename):
    return send_from_directory(STATIC_DIR, filename)


@app.route('/api/gardens', methods=['GET'])
def get_gardens():
    ensure_data_file()
    gardens = load_gardens_from_file(DATA_FILE)
    return jsonify(gardens_to_dict(gardens))


@app.route('/api/gardens', methods=['POST'])
def upsert_gardens():
    ensure_data_file()
    payload = request.get_json(silent=True) or {}
    # Expecting payload like {"gardens": [{"name":..., "plants": [{...}], "notifications": {...}}]}
    try:
        new_gardens = []
        for g in payload.get('gardens', []):
            garden = Garden(g.get('name', 'Garden'))
            for p in g.get('plants', []):
                plant = Plant(p.get('name', 'Plant'), p.get('type', 'Unknown'), p.get('size', 'Unknown'))
                if p.get('ai_status'):
                    plant.ai_status = p['ai_status']
                if p.get('last_watered'):
                    from datetime import datetime
                    try:
                        plant.last_watered = datetime.strptime(p['last_watered'], "%Y-%m-%d %H:%M")
                    except Exception:
                        plant.last_watered = None
                garden.add_plant(plant)
            if 'notifications' in g and isinstance(g['notifications'], dict):
                garden.notifications = g['notifications']
            new_gardens.append(garden)

        save_gardens_to_file(new_gardens, DATA_FILE)
        return jsonify({"ok": True}), 200
    except Exception as e:
        return jsonify({"ok": False, "error": str(e)}), 400


@app.route('/api/seed', methods=['POST'])
def seed():
    # quick helper to create a sample data set
    g1 = Garden("Արևոտ Այգի")
    p1 = Plant("Վարդ", "Flower", "Small")
    p1.ai_status = "Առողջ"
    p2 = Plant("Կաղնի", "Tree", "Large")
    p2.ai_status = "Ջուր է պետք"
    g1.add_plant(p1)
    g1.add_plant(p2)
    save_gardens_to_file([g1], DATA_FILE)
    return jsonify({"ok": True}), 200


if __name__ == '__main__':
    ensure_data_file()
    app.run(host='0.0.0.0', port=5000, debug=True)



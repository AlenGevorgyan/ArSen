from Main import Plant, Garden, save_gardens_to_file, load_gardens_from_file, gardens_to_dict


def create_sample_gardens():
    # Создаём несколько растений
    plant1 = Plant("Ficus", "Tree", "Medium")
    plant2 = Plant("Aloe Vera", "Succulent", "Small")
    plant3 = Plant("Monstera", "Leafy", "Large")

    # Поливаем и анализируем
    plant1.water()
    plant1.analyze("Healthy")

    plant2.water()
    plant2.analyze("Needs Water")

    plant3.analyze("Healthy")

    # Создаём сад и добавляем растения
    garden1 = Garden("Living Room")
    garden1.add_plant(plant1)
    garden1.add_plant(plant2)

    garden2 = Garden("Balcony")
    garden2.add_plant(plant3)

    return [garden1, garden2]


if __name__ == "__main__":
    gardens = create_sample_gardens()

    # Сохраняем в JSON
    save_gardens_to_file(gardens, "gardens.json")

    # Загружаем и проверяем
    loaded_gardens = load_gardens_from_file("gardens.json")
    print(gardens_to_dict(loaded_gardens))
